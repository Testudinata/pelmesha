from .msi_parse import *

__doc__ = msi_parse.__doc__
if hasattr(msi_parse, "__all__"):
    __all__ = msi_parse.__all__